class Queue:
    def __init__(self):
        self.a_in = []
        self.a_out = []
    def enqueue(self, d):
        self.a_in.append(d)
    def dequeue(self):
        if (self.a_out == []):
            for d in self.a_in:
                self.a_out.append(d)
            self.a_in = []
        return self.a_out.pop(0)