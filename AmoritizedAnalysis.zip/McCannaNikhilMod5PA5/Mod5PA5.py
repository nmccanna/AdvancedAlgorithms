import random

class Queue:
    def __init__(self):
        self.a_in = []
        self.a_out = []
        self.costly_operations = 0  # Counter for costly operations
        self.cheap_operations = 0  # Counter for cheap operations

    def enqueue(self, d):
        self.a_in.append(d)
        self.cheap_operations += 1  # Increment cheap operations counter

    def dequeue(self):
        if self.a_out == []:
            for d in self.a_in:
                self.a_out.append(d)
                self.costly_operations += 1  # Increment costly operations counter
            self.a_in = []
        if self.a_out:
            self.a_out.pop(0)
            self.cheap_operations += 1  # Increment cheap operations counter

    def counts(self):
        return self.costly_operations, self.cheap_operations

def main():
    while True:
        try:
            # 
            enqueue_ratio = float(input("Please enter a ratio for enqueue between 34 and 66 (dequeue will be its complement): "))
            if 34 <= enqueue_ratio <= 66:
                break
            else:
                print("Invalid input. Please enter a ratio for enqueue between 34 and 66 (dequeue will be its complement): ")
        except ValueError:
            print("Invalid input. Please enter a ratio for enqueue between 34 and 66 (dequeue will be its complement): ")
    
    # Convert the percentage to a decimal
    enqueue_ratio = enqueue_ratio / 100
    dequeue_ratio = 1.0 - enqueue_ratio

    # operations is a list of the two operations. probabilities is a list of the probabilities of each operation.
    operations = ["enqueue", "dequeue"]
    probabilities = [enqueue_ratio, dequeue_ratio]

    q = Queue()

    # Builds a queue with 100000 random operations in enqueue and dequeue
    for _ in range(100000):
        # 'Operation' is where one of the two operations will be chosen. The 'weights' are the probabilities of each operation. 
        # 'k=1' is the number of times the operation will be chosen. '0' is the index of the operation in the list. 
        operation = random.choices(operations, weights=probabilities, k=1)[0]
        if operation == "enqueue":
            # Enqueue a random integer between 1 and 100
            q.enqueue(random.randint(1, 100))
        else:
            # Otherwise, dequeue
            q.dequeue()

    costly, cheap = q.counts()

    print(f"Costly operations: {costly}")
    # Calculate the percentage of costly operations at two decimal places.
    print(f"Costly percent of operations: {(costly / 100000) * 100:.2f}%")
    print(f"Cheap operations: {cheap}")
    # Calculate the percentage of cheap operations at two decimal places.
    print(f"Cheap percent of operations: {(cheap / 100000) * 100:.2f}%" )

if __name__ == "__main__":
    main()

