# Tribonacci Sequence (Fibonacci but with 3 numbers)
def tribo(n):
    a, b, c = 1, 1, 1
    if n < 4:
        return 1
    for i in range(3, n):
        a, b, c = b, c, a + b + c
    return c

# Main method
def main():
    while True:
        try:
            # Prompt user for input
            n = int(input("Choose an Integer (or enter a number less than 1 to quit): "))
            # If n is less than 1, exit the program
            if n < 1:
                print("Exiting program.")
                break
            # Print the nth element of the Tribonacci sequence
            print("The {}-th element of Tribonacci sequence is {}.".format(n, tribo(n)))
        # ValueError exception
        except ValueError:
            print("Please enter a valid integer.")

main()


