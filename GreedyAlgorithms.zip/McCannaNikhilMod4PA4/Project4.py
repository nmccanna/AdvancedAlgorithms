import csv

# Open and read data from csv file
with open('items.csv', 'r') as f:
    reader = csv.reader(f)
    next(reader)  # Skip the header row
    # Extract columns and convert to appropriate data types
    names, values, heights, widths, depths = zip(*[(row[0], int(row[1]), int(row[2]), int(row[3]), int(row[4])) for row in reader])

def knapsack(v, w, names, cap):
    # Sort items in descending order
    items = sorted([(v[i]/w[i], w[i], v[i], i) for i in range(len(v))], reverse=True)
    ans = {}  # Dictionary to store the quantities of selected items
    total_value = 0  # Total value of selected items
    total_volume = 0  # Total volume of selected items

    # Keep adding items to the knapsack as long as total volume does not exceed capacity
    while total_volume < cap:
        for item in items:
            if (item[1] + total_volume) <= cap:
                # If an item fits, add it to the knapsack and update total value and volume
                ans[names[item[3]]] = ans.get(names[item[3]], 0) + 1
                total_value += item[2]
                total_volume += item[1]
        # If all of the remaining items are too large to fit, break the loop
        if all(item[1] + total_volume > cap for item in items):
            break

    # Return selected items, total value, and leftover space
    return ans, total_value, cap - total_volume

def main(values, heights, widths, depths, names):
    values = list(values)  # List of item values
    # List of item volumes calculated as height * width * depth
    volumes = [heights[i] * widths[i] * depths[i] for i in range(len(values))]

    while True:
        try:
            cap = int(input('Enter the volume limit: '))  # The capacity of the knapsack
            break
        except ValueError:
            print('Invalid input. Please enter an integer.')

    # Perform knapsack algorithm
    selected_items, total_value, leftover_space = knapsack(values, volumes, list(names), cap)

    # Create a string listing the selected items
    items_list = [f'{quantity} {name}' for name, quantity in selected_items.items()]
    if len(items_list) > 1:
        last = items_list.pop(-1)  # Remove the last item
        # Join all items into a string, with an "and" before the last item
        items_str = ', '.join(items_list) + ' and ' + last
    else:
        items_str = items_list[0]  # If only one item is selected, use it as the string

    # Print the selected items, total value, and leftover space
    print(f'The suggested items are: {items_str} with a total value of ${total_value}. There were {leftover_space} square inches left unused.')

# Call the main function with the data read from the csv file
main(values, heights, widths, depths, names)




