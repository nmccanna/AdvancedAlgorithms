import numpy as np

# Linear programming solver
def linear_programming_solver(x, f, A, b):
    # Create numpy arrays
    f = np.array(f)
    A = np.array(A)
    b = np.array(b)
    
    # Calculate the balanced solution
    A_inv = np.linalg.inv(A)
    balanced_solution = np.dot(A_inv, b)
    balanced_profit = np.dot(f, balanced_solution)
    
    # Calculate the solo options
    solo_profits = []
    solo_units = []
    for i in range(x):
        # Calculate how much of variable i can be produced based on each constraint
        production_based_on_constraints = [b[j] / A[j][i] if A[j][i] != 0 else float('inf') for j in range(x)]
        # Choose the minimum value as the feasible production
        solo_solution_value = min(production_based_on_constraints)
        solo_units.append(solo_solution_value)
        solo_solution = np.zeros(x)
        solo_solution[i] = solo_solution_value
        profit = np.dot(f, solo_solution)
        solo_profits.append(profit)
    
    # Determine the best option
    max_solo_profit = max(solo_profits)
    if balanced_profit > max_solo_profit:
        best_option = "balanced"
        best_profit = balanced_profit
    else:
        best_option = "solo " + str(solo_profits.index(max_solo_profit) + 1)
        best_profit = max_solo_profit
    
    # Printing the results
    results = {}
    results["chart"] = f"Objective: {f}\nConstraints:\n"
    for row in A:
        results["chart"] += str(row) + "\n"
    results["chart"] += f"b: {b}"
    
    results["solo_profits"] = solo_profits
    results["solo_units"] = solo_units
    results["balanced_solution"] = balanced_solution
    results["balanced_profit"] = balanced_profit
    results["best_option"] = best_option
    results["best_profit"] = best_profit
    
    return results

# Display the results
def display_results(results):
    # Chart of the setup
    print("\n")
    print("Chart of the setup:")

    # Objective
    print("Objective", end="  ")
    for coeff in results["chart"].split("Objective: ")[1].split("\nConstraints:")[0].strip().split():
        print(f"{coeff}", end="  ")
    print("\n")
    
    # Constraints
    constraints_data = results["chart"].split("Constraints:\n")[1].split("\nb:")[0].strip().split("\n")
    print("  ", end=" ")
    for i in range(len(constraints_data)):
        print(f"c{i+1}", end="  ")
    print()
    
    for i, row in enumerate(constraints_data):
        print(f"x{i+1} {row}")
    print("b", results["chart"].split("\nb: ")[1])
    
    print("\nSolo option profit amounts:")
    for i, (profit, units) in enumerate(zip(results["solo_profits"], results["solo_units"])):
        print(f"For x{i+1} based on {units:.2f} units ${profit:,.2f}")
    
    # Balanced option details
    print("\nBalanced option:")
    for i, amount in enumerate(results["balanced_solution"]):
        print(f"Amount of variable x{i+1} {amount:.2f}")
    print(f"Profit for balanced option ${results['balanced_profit']:,.2f}")

    # Conclusion
    print("\nConclusion:")
    if "solo" in results["best_option"]:
        idx = int(results["best_option"].split()[-1])
        print(f"The best option is to produce x{idx} alone with a profit of ${results['best_profit']:,.2f}.")
    else:
        print(f"The best option is the balanced solution with a profit of ${results['best_profit']:,.2f}.")
    print("\n")

# Get user input
def get_user_input():
    while True:
        try:
            # Get the number of variables/constraints
            x = int(input("Enter the number of variables (also the number of constraints): "))
            if x <= 0:
                print("Please enter a positive integer.")
                continue
            
            # Get the objective function coefficients
            f = []
            for i in range(x):
                while True:
                    try:
                        coeff = float(input(f"Enter the coefficient for variable x{i+1} in the objective function: "))
                        f.append(coeff)
                        break
                    except ValueError:
                        print("Invalid input. Please enter a valid number.")
            
            # Get the constraint coefficients
            A = []
            print("\nEnter the coefficients for the constraints:")
            for i in range(x):
                row = []
                for j in range(x):
                    while True:
                        try:
                            coeff = float(input(f"Enter the coefficient of variable x{j+1} in constraint {i+1}: "))
                            row.append(coeff)
                            break
                        except ValueError:
                            print("Invalid input. Please enter a valid number.")
                A.append(row)
            
            # Get the constraint limits
            b = []
            for i in range(x):
                while True:
                    try:
                        limit = float(input(f"Enter the limit for constraint {i+1}: "))
                        b.append(limit)
                        break
                    except ValueError:
                        print("Invalid input. Please enter a valid number.")
            
            return x, f, A, b
        
        except ValueError:
            print("Invalid input. Please enter a valid number.")

# Capture user input
user_data = get_user_input()

# Use the captured data in the solver
user_results = linear_programming_solver(*user_data)

# Display the results
display_results(user_results)

'''
********* Pants and Jackets Problem **********

Enter the number of variables (also the number of constraints): 2
Enter the coefficient for variable x1 in the objective function: 50
Enter the coefficient for variable x2 in the objective function: 40

Enter the coefficients for the constraints:
Enter the coefficient of variable x1 in constraint 1: 2
Enter the coefficient of variable x2 in constraint 1: 3
Enter the coefficient of variable x1 in constraint 2: 2
Enter the coefficient of variable x2 in constraint 2: 1
Enter the limit for constraint 1: 1500
Enter the limit for constraint 2: 1000


Chart of the setup:
Objective  [50.  40.]

   c1  c2
x1 [2. 3.]
x2 [2. 1.]
b [1500. 1000.]

Solo option profit amounts:
For x1 based on 500.00 units $25,000.00
For x2 based on 500.00 units $20,000.00

Balanced option:
Amount of variable x1 375.00
Amount of variable x2 250.00
Profit for balanced option $28,750.00

Conclusion:
The best option is the balanced solution with a profit of $28,750.00.
'''

#--------------------------------------------------------------------------------

'''
********* Chemical Production Problem *********

Enter the number of variables (also the number of constraints): 3
Enter the coefficient for variable x1 in the objective function: 3000
Enter the coefficient for variable x2 in the objective function: 2000
Enter the coefficient for variable x3 in the objective function: 2000

Enter the coefficients for the constraints:
Enter the coefficient of variable x1 in constraint 1: 2
Enter the coefficient of variable x2 in constraint 1: 4
Enter the coefficient of variable x3 in constraint 1: 5
Enter the coefficient of variable x1 in constraint 2: 1
Enter the coefficient of variable x2 in constraint 2: 2
Enter the coefficient of variable x3 in constraint 2: 4
Enter the coefficient of variable x1 in constraint 3: 8
Enter the coefficient of variable x2 in constraint 3: 0
Enter the coefficient of variable x3 in constraint 3: 3
Enter the limit for constraint 1: 300
Enter the limit for constraint 2: 200
Enter the limit for constraint 3: 300


Chart of the setup:
Objective  [3000.  2000.  2000.]
   c1  c2  c3
x1 [2. 4. 5.]
x2 [1. 2. 4.]
x3 [8. 0. 3.]
b [300. 200. 300.]

Solo option profit amounts:
For x1 based on 37.50 units $112,500.00
For x2 based on 75.00 units $150,000.00
For x3 based on 50.00 units $100,000.00

Balanced option:
Amount of variable x1 25.00
Amount of variable x2 20.83
Amount of variable x3 33.33
Profit for balanced option $183,333.33

Conclusion:
The best option is the balanced solution with a profit of $183,333.33.
'''