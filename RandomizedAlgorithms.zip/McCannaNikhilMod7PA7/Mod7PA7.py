from math import log2
import random

# Provided myFunction
def myFunction(x):
    if (x == 0):
        return 0
    elif ((log2(x) * 7) % 17) < (x % 13):
        return (x + log2(x))**3
    elif ((log2(x) * 5) % 23) < (x % 19):
        return (log2(x)*2)**3
    else:
        return (log2(x)**2) - x

# Function to perform hill climbing
def hillClimb(arr, start_index):
    current_index = start_index
    
    # Initial print statement
    print(f"Starting hill climb at index {current_index} with value {arr[current_index]:.2f}")

    while 0 <= current_index < len(arr):
        # If at the boundaries, return the current value
        if current_index == 0 or current_index == len(arr) - 1:
            print(f"Reached boundary at index {current_index} with value {arr[current_index]:.2f}")
            return current_index, arr[current_index]

        # Get the values to the left, right, and current
        left_value = arr[current_index - 1]
        current_value = arr[current_index]
        right_value = arr[current_index + 1]

        # Check for local maximum
        if left_value < current_value > right_value:
            print(f"Found local maximum at index {current_index} with value {current_value:.2f}")
            return current_index, current_value

        # If in a pit
        if current_value < left_value and current_value < right_value:
            # Equal increases to left and right
            if left_value - current_value == right_value - current_value:
                print(f"Equal increases on both sides. Moving right from index {current_index}")
                current_index += 1
            # Unequal increases, move in the direction of greater increase
            else:
                if left_value > right_value:
                    print(f"Greater increase on the left. Moving left from index {current_index}")
                    current_index -= 1
                else:
                    print(f"Greater increase on the right. Moving right from index {current_index}")
                    current_index += 1
            continue
        
        # If on a shoulder or plateau
        if current_value == right_value:
            potential_peak_index = current_index
            print(f"Detected a shoulder at index {current_index}. Moving right to find its end...")
            while potential_peak_index < len(arr) - 1 and arr[potential_peak_index] == arr[potential_peak_index + 1]:
                potential_peak_index += 1
            if arr[potential_peak_index] >= arr[potential_peak_index + 1] or potential_peak_index == len(arr) - 1:
                print(f"End of shoulder reached at index {potential_peak_index} with value {arr[potential_peak_index]:.2f}")
                return potential_peak_index, arr[potential_peak_index]
            else:
                current_index = potential_peak_index + 1
                continue
        
        if current_value == left_value:
            potential_peak_index = current_index
            print(f"Detected a shoulder at index {current_index}. Moving left to find its end...")
            while potential_peak_index > 0 and arr[potential_peak_index] == arr[potential_peak_index - 1]:
                potential_peak_index -= 1
            if arr[potential_peak_index] >= arr[potential_peak_index - 1] or potential_peak_index == 0:
                print(f"End of shoulder reached at index {potential_peak_index} with value {arr[potential_peak_index]:.2f}")
                return potential_peak_index, arr[potential_peak_index]
            else:
                current_index = potential_peak_index - 1
                continue

        # Decide which direction to move
        if left_value < current_value < right_value:
            print(f"Moving right from index {current_index}")
            current_index += 1
        else:
            print(f"Moving left from index {current_index}")
            current_index -= 1

# Function to find the maximum
def main():
    # Generate the array of results
    arr = [myFunction(x) for x in range(10000)] 
    
    # Randomly select a start value between 1 and 9998
    start_index = random.randint(1, 9998)
    
    # Use this start value as the start_index for the hillClimb function
    return hillClimb(arr, start_index)

# Call the function
main()