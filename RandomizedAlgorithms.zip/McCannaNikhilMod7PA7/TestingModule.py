
# Function to perform hill climbing
def hillClimb(arr, start_index):
    current_index = start_index

    # Initial print statement
    print(f"Starting hill climb at index {current_index} with value {arr[current_index]}")

    while 0 <= current_index < len(arr):
        # If at the boundaries, return the current value
        if current_index == 0 or current_index == len(arr) - 1:
            print(f"Reached boundary at index {current_index} with value {arr[current_index]}")
            return current_index, arr[current_index]

        left_value = arr[current_index - 1]
        current_value = arr[current_index]
        right_value = arr[current_index + 1]

        # Check for local maximum
        if left_value < current_value > right_value:
            print(f"Found local maximum at index {current_index} with value {current_value}")
            return current_index, current_value

        # If in a pit
        if current_value < left_value and current_value < right_value:
            # Equal increases to left and right
            if left_value - current_value == right_value - current_value:
                print(f"Equal increases on both sides. Moving right from index {current_index}")
                current_index += 1
            # Unequal increases, move in the direction of greater increase
            else:
                if left_value > right_value:
                    print(f"Greater increase on the left. Moving left from index {current_index}")
                    current_index -= 1
                else:
                    print(f"Greater increase on the right. Moving right from index {current_index}")
                    current_index += 1
            continue
        
        # If on a shoulder / plateau
        if current_value == right_value:
            potential_peak_index = current_index
            print(f"Detected a shoulder at index {current_index}. Moving right to find its end...")
            while potential_peak_index < len(arr) - 1 and arr[potential_peak_index] == arr[potential_peak_index + 1]:
                potential_peak_index += 1
            if arr[potential_peak_index] >= arr[potential_peak_index + 1] or potential_peak_index == len(arr) - 1:
                print(f"End of shoulder reached at index {potential_peak_index} with value {arr[potential_peak_index]}")
                return potential_peak_index, arr[potential_peak_index]
            else:
                current_index = potential_peak_index + 1
                continue

        if current_value == left_value:
            potential_peak_index = current_index
            print(f"Detected a shoulder at index {current_index}. Moving left to find its end...")
            while potential_peak_index > 0 and arr[potential_peak_index] == arr[potential_peak_index - 1]:
                potential_peak_index -= 1
            if arr[potential_peak_index] >= arr[potential_peak_index - 1] or potential_peak_index == 0:
                print(f"End of shoulder reached at index {potential_peak_index} with value {arr[potential_peak_index]}")
                return potential_peak_index, arr[potential_peak_index]
            else:
                current_index = potential_peak_index - 1
                continue

        # Decide which direction to move
        if left_value < current_value < right_value:
            print(f"Moving right from index {current_index}")
            current_index += 1
        else:
            print(f"Moving left from index {current_index}")
            current_index -= 1

# Testing the hillClimb function
printed_test_results = [
    hillClimb([6, 5, 5, 5, 4, 3, 2], 5),
    #hillClimb([2, 5, 5, 5, 4, 3, 2], 5),
    #hillClimb([1, 2, 3, 6, 3, 6, 10, 10, 10, 17, 15, 27], 4),
    #hillClimb([1, 2, 3, 6, 3, 7, 12, 12, 12, 14, 34, 18, 2], 4)
    #hillClimb([1, 2, 3, 7, 3, 6, 12, 12, 12, 14, 34, 18, 2], 4)
    #  Index   0  1  2  3  4  5   6   7   8   9  10  11  12
]

printed_test_results

