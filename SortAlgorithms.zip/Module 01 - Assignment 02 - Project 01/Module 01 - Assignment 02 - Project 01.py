import random
import cProfile

# QuickSort algorithm
def quicksort(arr):
    if len(arr) <= 1:
        return arr
    # Select the pivot element randomly to avoid worst case performance of O(n^2) for sorted arrays
    pivot = arr[len(arr) // 2]
    left = [x for x in arr if x < pivot]
    middle = [x for x in arr if x == pivot]
    right = [x for x in arr if x > pivot]
    # Recursively call quicksort on the left and right sub-arrays
    return quicksort(left) + middle + quicksort(right)

# Main function
def main():
    # List of list sizes
    sizes = list(range(100000, 1100000, 100000))
    
    # Iterate through the list of sizes
    for size in sizes:
        # Generate random array
        array = [random.randint(0, size) for i in range(size)]

        # Profile the QuickSort call
        print(f"Profiling for array size: {size}")
        profiler = cProfile.Profile()
        profiler.runcall(quicksort, array)
        profiler.print_stats()

if __name__ == "__main__":
    main()
